# Text files 

# f = open("sample.txt", "r") # Will open file in read mode
# f = open("sample.txt", "w") # Will open file in write mode
# f = open("sample.txt", "a") # Will open file in append mode
# f = open("sample.txt", "+") # Will open file in update mode i.e read and write mode

# Binary files 

f = open("image.jfif", "br") # Will open file in read mode 
