with open("deleted.txt", "w") as f:
    f.write("")


