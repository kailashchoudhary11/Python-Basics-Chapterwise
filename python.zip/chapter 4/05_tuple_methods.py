t = (1, 2, 4, 5, 1, 1, 1, 1)
# print(t)

# Methods used for tuples

print(t.count(1)) # Will count the number of occurrences of 2 in the tuple t
print(t.index(5)) # Will return the index of the first occurrence of the given element in the list

