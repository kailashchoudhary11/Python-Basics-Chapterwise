t = (9, 8, 3, 5)

t[2] = 33 # This throws an error hence tuple cannot be modified
print(t)
