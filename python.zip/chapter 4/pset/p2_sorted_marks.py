s1 = int(input("Marks of student 1: "))
s2 = int(input("Marks of student 2: "))
s3 = int(input("Marks of student 3: "))
s4 = int(input("Marks of student 4: "))
s5 = int(input("Marks of student 5: "))
s6 = int(input("Marks of student 6: "))

marksOfStudents = [s1, s2, s3, s4, s5, s6]
marksOfStudents.sort()
print(marksOfStudents)