l = [3, 5, 8, 11]
print(l[0] + l[1] + l[2] + l[3])
print(sum(l))