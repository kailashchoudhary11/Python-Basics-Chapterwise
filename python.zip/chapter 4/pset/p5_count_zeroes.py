a = (7, 0, 8, 0, 0, 9)

# This will print the number of occurrences of 0 in the tuple a
print(a.count(0))
