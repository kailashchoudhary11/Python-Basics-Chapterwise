f1 = input("Enter the name of fruit 1: ")
f2 = input("Enter the name of fruit 2: ")
f3 = input("Enter the name of fruit 3: ")
f4 = input("Enter the name of fruit 4: ")
f5 = input("Enter the name of fruit 5: ")
f6 = input("Enter the name of fruit 6: ")
f7 = input("Enter the name of fruit 7: ")

fruits = [f1, f2, f3, f4, f5, f6, f7]
print(fruits)