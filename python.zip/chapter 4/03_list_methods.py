l1 = [1, 8 , 7, 2, 21, 15]

# l1_sorted = l1.sort() # The list l1_sorted will be empty as the sort method won't return a sorted list indeed it will sort the list which is passed to the function
# print(l1_sorted) # This will print none as the list is empty

# l1.sort() # This will sort the list l1 and store it in l1
# print(l1)

# l1.reverse() # Will reverse the list the first element will become last and last will become first
# print(l1)

# l1.append(33) # Will add the element at the end of the list 
# l1.append(81) # Will add 81 at the end of the list 
# print(l1)

# l1.insert(0, 544) # Will add the given element at the specified index in the list 
# l1.insert(3, 928) # Will add the number 928 at index 3 in the list l1
# print(l1)

# l1.pop(2) # Will remove the element at the specified index in the list
# l1.pop() # Will remove the last element in the list
# print(l1)

# l1.remove(21) # Will remove the specified element from the list
# l1.remove(2) # This will remove the number 2 from the list
# print(l1)

print(l1)
# print(l1.index(2)) # Will return the index of the given element in the list

# print(l1.count(2)) # Will return the number of times the given element occurs in the list

# print(len(l1)) # Length of the list

# print(min(l1)) # minimum element in the list

# print(max(l1)) # maximum element in the list

# print(sum(l1)) # sum of all the elements in the list

# print(sorted(l1)) # prints the sorted list

# l1.clear() # Removes all the elements from the list
print(l1)