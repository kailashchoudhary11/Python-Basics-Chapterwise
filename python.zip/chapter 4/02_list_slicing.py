# Similar to string, we can also do slicing in list 
# print(c[2:3])
# print(c[1:])
# print(c[:2])
# print(c[0::2]) # This will print every 2nd letter 

friends = ["kai", "jackie", "tyson", "max", 33]
# print(friends[0:4])
print(friends[2:])
print(friends[-3: -1])