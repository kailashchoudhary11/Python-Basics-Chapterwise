# Set is a collection of non repetitive items in python

s = {1, 3, 4, 5, 1}

print(s)
print(type(s))
