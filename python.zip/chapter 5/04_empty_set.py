# Important
d = {} # This will create an empty dictionary and not an empty set 
print(type(d))

# An empty set can be created using below syntax 
s = set()
print(type(s))

