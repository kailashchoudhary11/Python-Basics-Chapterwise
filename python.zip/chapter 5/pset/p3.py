s = {18, "18"} # This will work as the datatypes are different
print(len(s))
print(s)