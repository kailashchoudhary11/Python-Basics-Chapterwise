s = {}
print(type(s))

# The type of s is dictionary. Syntax for creating empty set is as follows
s1 = set()
print(type(s1))
