f1 = input("Enter your Favorite Language Rohit: ")
f2 = input("Enter your Favorite Language Rahul: ")
f3 = input("Enter your Favorite Language Rohan: ")
f4 = input("Enter your Favorite Language Rahul: ")

favLang = {
    "Rohit" : f1,
    "Rahul" : f2,
    "Rohan" : f3,
    "Rahul" : f4
}
# If two keys are same then the value associated with the last key will be updated 
print(favLang)