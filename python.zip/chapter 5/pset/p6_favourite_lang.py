f1 = input("Enter your Favorite Language Rohit: ")
f2 = input("Enter your Favorite Language Rahul: ")
f3 = input("Enter your Favorite Language Rohan: ")
f4 = input("Enter your Favorite Language Rajneesh: ")

favLang = {
    "Rohit" : f1,
    "Rahul" : f2,
    "Rohan" : f3,
    "Rajneesh" : f4
}

print(favLang)