str = "    Kai is a good boy   "
print(str)

# strip() method removes the spaces from back and front in a string
print(str.strip())

str2 = "                        Kai is a good boy"
print(str2.strip())