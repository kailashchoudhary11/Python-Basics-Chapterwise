a = 34

# If we want to use single quote in the string then we can enclose it within double quotes
# b = "kai's"
# print(b)

# If we want to use double quote inside the string then we can enclose the string in single quotes
# c = 'kai"s'
# print(c)

# If you want to use single quote and double quote inside the string then enclose it within triple quotes
# d = '''kai"s and kai's '''
# print(d)

# Triple quote can also be used when your string contains multiple lines 
# e = '''This is
# new line 
# another new line'''
# print(e)




