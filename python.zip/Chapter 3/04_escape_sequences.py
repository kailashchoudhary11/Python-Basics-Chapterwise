# \n is used to print a new line and \t is used to print a tab 

story = "Kai is awesome.\nHe is really awesome.\tDon't forget him guys"

# similarly we can use \' \" \\ etc

print(story)