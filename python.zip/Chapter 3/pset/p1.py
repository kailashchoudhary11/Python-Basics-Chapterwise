# Display user entered name followed by Good Afternoon 
name = input("Enter your name\n")
print("Good Afternoon, " + name)