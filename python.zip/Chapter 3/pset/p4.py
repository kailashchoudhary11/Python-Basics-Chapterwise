str = "This  String Contains  double  spaces  "
str = str.replace("  ", " ")
print(str)