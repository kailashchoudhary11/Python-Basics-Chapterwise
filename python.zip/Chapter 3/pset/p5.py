letter = "\nDear Harry,\n\tThis Python Course is awesome.\nThank you!\nFrom Kai"
print(letter)  