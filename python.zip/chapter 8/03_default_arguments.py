def greet(name = "gumnam"):
    print("Namaste, " + name)

greet("kai")
greet()