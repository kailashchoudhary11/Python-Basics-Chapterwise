def getPercentage(marks):
    return sum(marks) / len(marks)

marks = [45, 78, 86, 77]
# percentage = (sum(marks) / 4) 
print(getPercentage(marks))

marks2 = [75, 98, 88, 78]
# percentage2 = (sum(marks2) / 4)
print(getPercentage(marks2))
