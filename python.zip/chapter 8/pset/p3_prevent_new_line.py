print("Avoiding new line.", end = " ")
print("This won't be printed on new line", end = "")