def greet(name):
    print("Namaste, " + name)

name = input("Enter your name: ")
greet(name)

def sum(num1, num2):
    return num1 + num2

print(sum(33, 99))