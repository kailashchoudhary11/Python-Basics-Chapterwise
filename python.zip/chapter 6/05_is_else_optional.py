a = 2
if(a == 8):
    print("yes")
elif(a > 9):
    print("No")


# Hence proved that else is optional 