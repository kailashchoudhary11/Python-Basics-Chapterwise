marks = int(input("Please Enter Your Marks: "))

if (marks >= 90):
    print("Your grade is Ex")
elif (marks >= 80):
    print("Your grade is A")
elif (marks >= 70):
    print("Your grade is B")
elif (marks >= 60):
    print("Your grade is C")
elif (marks >= 50):
    print("Your grade is D")
else:
    print("Your grade is F")