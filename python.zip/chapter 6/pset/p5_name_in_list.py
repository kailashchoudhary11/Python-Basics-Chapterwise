names = ["kai", "ray", "max", "jackie", "tyson"]
name = input("Enter the name: ")

if (name in names):
    print("The given name is present in the list")
else:
    print("The given name is not present in the list")