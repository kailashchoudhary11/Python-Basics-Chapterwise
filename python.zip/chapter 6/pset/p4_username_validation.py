username = input("Enter your username: ")
if (len(username) < 10):
    print("The username contains less than 10 characters")
else:
    print("The username does not contain less than 10 characters")
