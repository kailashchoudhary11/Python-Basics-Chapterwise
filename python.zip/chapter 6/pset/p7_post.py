post = input("Enter the post\n")
post = post.lower()
if ("kai" in post):
    print("The post is talking about kai")
else:
    print('The post is not talking about kai')