# a = None
# if (a is None):
#     print("Yes")
# else:
#     print("No")

a = [45, 56, 6]

print(45 in a) # Will return true if the given element is present in the list
print(3 in a) # Since 3 is not present in a. It will return false

