# age = int(input("Enter your age: "))

# Logical Operators

# Logical and operator 
# if (age > 34 and age < 56):  # The and operator is similar to && operator in java and c
#     print("You can work with us")
# else:
#     print("You cannot work with us")

# logical or operator
# key = 0
# if (age >= 18 or key == 1): # Same as || operator in java and c
#     print("You are eligible!")
# else:
#     print("You are not eligible")

# Logical not operator
isTrue = True

if (not isTrue):
    print("It is false")
else:
    print("True")