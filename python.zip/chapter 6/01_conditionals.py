a = 8

# This is called if-elif-else ladder in python
# if (a < 3):
#     # We use indentation to show that the following statement is within if condition
#     print("The value of a is greater than 3")
# elif (a > 13):
#     print("The value of a is greater than 13")
# elif (a > 7):
#     print("The value of a is greater than 7")
# elif (a > 17):
#     print("The value of a is greater than 17")
# else:
#     print("The value of a is not greater than 3 or 7")

# print("Done!")

a = 30

# Multiple if statements
if (a < 3):
    print("The value of a is less than 3")
if (a > 13):
    print("The value of a is greater than 13")
if (a > 7):
    print("The value of a is greater than 7")
if (a > 17):
    print("The value of a is greater than 17")
