class Employee:
    pass

kai = Employee()

# kai.name = "kai"

print(kai.name) # This will throw error if we comment out line number 6