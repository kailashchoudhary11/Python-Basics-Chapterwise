# defining a class 
class Employee:
    pass

# Instantiating objects of the class 
kai = Employee()
ray = Employee()

# Updating values of instance attributes
kai.name = "kai"
kai.salary = 250

ray.name = "ray"
ray.salary = 300

# Printing the values of instance attributes
print(kai.name, kai.salary)
print(ray.name, ray.salary)