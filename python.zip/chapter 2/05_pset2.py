# Adding 2 numbers in python
# a = 30
# b = 45
# print("Sum of a and b is", a + b)

# Finding remainder when a number is divided by 2

# print("The remainder when a is divided by 2 is", a % 2)
# print("The remainder when b is divided by 2 is", b % 2)

# Checking the type of the variable assigned using input function

# c = input("Enter anything ")
# print(type(c))

# use comparison operator to find whether a given variable a is greater than b or not 
# a = input("Enter the value of a ")
# b = input("Enter the value of b ")
# print(a > b)

# Program to find the average of 2 numbers entered by the user
# a = input("Enter the value of a ")
# b = input("Enter the value of b ")
# avg = (int(a) + int(b)) / 2
# print("Average of a and b is", avg)


# Program to find the square of the number entered by the user 

num = int(input("Enter a number "))
print("The square of the number you entered is", num * num )

