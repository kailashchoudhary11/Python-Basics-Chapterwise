# a = "35"
# a = int(a)

# type(variable_name) gives the data type of the variable
# print(type(a))

# a = "35gshalfj34"
# a = int(a) # this is considered invalid as the a cannot be converted to valid integer
# print(type(a))


print(str(34))
print(int(34))
print(float(34))
print(type(str(34)))
print(type(int(34)))
print(type(float(34)))