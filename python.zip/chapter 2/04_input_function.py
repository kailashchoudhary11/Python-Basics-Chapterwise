# By default all the values taken from the input funciton are string
a = input("Enter your name: ")
print(a)
# Convert a to an integer if possible
a = int(a)
print(type(a))
