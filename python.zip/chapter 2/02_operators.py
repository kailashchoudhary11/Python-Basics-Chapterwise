a = 8;
b = 9

# Arithmetic Operators

# print(a+b)
# print(a-b)
# print(a*b)
# print(a/b)


# Assignment operators
a += 3;
a -= 3;
a *= 3;
a /= 3;

a = True
b = False

# Logical Operators

print((a and b))
print((a or b))
print(not a)
print(not b)