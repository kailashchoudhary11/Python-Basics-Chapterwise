# declaring the variables

a = "kai is a programmer"
a = 'kai is here'
a = '''kai is here with you all and he will teach you all python'''
b = 11
c = 334.543
d = True
d = False
e = None

# printing the variables

# print(d)
# print(c)
# print(b)
# print(a)

# printing the data types of variables

print(a);

print(type(a))
print(type(b))
print(type(c))
print(type(d))
print(type(e))
