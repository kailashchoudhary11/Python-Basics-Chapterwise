# By default the value of i will start from 0 and increment by 1
# for i in range(8):
#     print(i)

# Here the value of i will start from 1 and go upto 8 and increment by 1 after each iteration
# for i in range(1, 8):
    # print(i)

# Here the i will start from 2 and increment by 2 after each iteration till it reaches upto 8
# for i in range(2, 8, 2):
    # print(i)

for i in range(0, 10, 2):
    print(i)