num = 1
while (num <= 50):
    print(str(num))
    num += 1