for i in range(10):
    print(i)
    if i == 5:
        break
# This else will be executed only if the loop is successfully executed completely. If there is break, the statement inside else won't be executed
else: 
    print("Done!") 
