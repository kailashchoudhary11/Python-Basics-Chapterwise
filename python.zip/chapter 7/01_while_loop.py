i = 0
while (i < 10):
    print("Yes! " + str(i))
    i += 1