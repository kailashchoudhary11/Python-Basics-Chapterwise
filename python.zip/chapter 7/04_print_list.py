fruits = ["apple", "mango", "banana", "orange", "kiwi"]
i = 0
while (i < len(fruits)):
    print(fruits[i])
    i += 1