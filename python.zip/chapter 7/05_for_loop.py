nums = [1, 3, 5, 7, 9, 11]
for num in nums:
    print(num)