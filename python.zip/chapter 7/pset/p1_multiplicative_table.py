num = int(input("Enter the number:\n"))

for i in range(1, 11):
    print(str(num) + " x " + str(i) + " = " + str(num * i))



