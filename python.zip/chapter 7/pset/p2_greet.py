names = ["kai", "ray", "rohan", "rahul"]

for name in names:
    # if (name[0] == "r"):
    if (name.startswith("r")):
        print(f"Namaste, {name}")