i = 4
if i > 0:
    pass # pass is similar to do nothing. It is a null statement in python
else:
    print("Not greater than 4")

while (i > 8):
    pass

def sum(i):
    pass 