for i in range(10):
    print(i)
else:
    print("This is inside else of for") # This will be executed once the condition inside for loop becomes false