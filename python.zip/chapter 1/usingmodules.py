from playsound import playsound
playsound('E:\\New folder\\Programming languages\\python programming\\chapter 1\\play.mp3')

import os

print(os.listdir())