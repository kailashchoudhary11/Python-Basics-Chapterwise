'''

This is the solution of question number 1
we can write multi line strings using 3 single quotes 
and we can use 3 single quotes for multi line comments as well
and for single line comments we can use #
'''

#comment

print('''Twinkle, twinkle, little star,
How I wonder what you are!
Up above the world so high,
Like a diamond in the sky.
''')


