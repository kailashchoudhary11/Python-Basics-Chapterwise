#this is comment section and it is not executed 
print("Namaste Bharat")